package Examen.jd.guzman23;
import java.util.Random;

public interface EnergyEfficient {
	public float calculateEnergyUsage();
	
}
