package Examen.jd.guzman23;

public class SmartLight extends Light implements EnergyEfficient  {

	

	public SmartLight(boolean isOn, int id) {
		super(isOn, id);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float calculateEnergyUsage() {
		
		// TODO Auto-generated method stub
		
		double rand= Math.random();
		
		return (float) rand;
	}


}
