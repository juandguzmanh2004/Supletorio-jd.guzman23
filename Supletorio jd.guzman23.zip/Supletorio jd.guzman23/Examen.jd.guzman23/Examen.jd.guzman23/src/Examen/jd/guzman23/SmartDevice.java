package Examen.jd.guzman23;

public abstract class SmartDevice implements Device {
	
	private boolean isOn;
	private int id;
	
	public SmartDevice(int id) {
		super();
		this.isOn = isOn;
		this.id = id;	
}
	public boolean equals(Object o) {
		return false;
		
	}
	
	public boolean isOn() {
		return isOn;
	}
	
	@Override
	public void turnOff() {
		this.isOn=false;
	}
	
	@Override
	public void turnOn() {
		this.isOn=true;
	}
	
	

}

	
