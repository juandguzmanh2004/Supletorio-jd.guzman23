package Examen.jd.guzman23;

public class Light extends SmartDevice {

	private int brightness;

	public Light(boolean isOn, int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getStatus() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void setBrightness( int brightness) {
		this.brightness= brightness;
		
	}
	
	
	
	
	

}
