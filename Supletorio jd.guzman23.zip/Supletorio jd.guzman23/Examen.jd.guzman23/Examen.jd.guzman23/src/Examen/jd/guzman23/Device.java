package Examen.jd.guzman23;

public interface Device {
	
	public void turnOn();
	
	public void turnOff();
	
	public String getStatus();
	

}
