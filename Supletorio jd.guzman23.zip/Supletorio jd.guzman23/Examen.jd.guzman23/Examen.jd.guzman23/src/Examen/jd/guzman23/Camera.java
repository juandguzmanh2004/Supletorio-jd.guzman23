package Examen.jd.guzman23;

public class Camera extends SmartDevice{

	
	
	private static String StringHD= "HD";
	private static String FHD= "FULL HD";
	private static String FOURK= "4K";
	protected String resolution;
	private int id;
	@Override
	public String getStatus() {
		// TODO Auto-generated method stub
		return null;
	}
	public Camera(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

	
	}
	
	
	
	

