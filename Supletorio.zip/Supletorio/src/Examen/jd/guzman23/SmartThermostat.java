package Examen.jd.guzman23;

public class SmartThermostat extends Thermostat implements EnergyEfficient{

	public SmartThermostat(boolean isOn, int id) {
		super(id);
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public float calculateEnergyUsage() {
		// TODO Auto-generated method stub
		
		double random= Math.random();
		
		return (float) random;
	}

	

}
