package Examen.jd.guzman23;

import java.util.List;

public class SmartHome {
	private List<Device> devices;

	public SmartHome(List<Device> devices) {
		super();
		this.devices = devices;
	}
	
	public void addDevice(Device device) {
		devices.add(device);
		
	}
	public void removeDevice(Device device) {
		devices.remove(device);
		
	}
	

}
