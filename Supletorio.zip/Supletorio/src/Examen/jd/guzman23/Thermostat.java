package Examen.jd.guzman23;

public class Thermostat extends SmartDevice {

	private double temperature;
	
	public Thermostat(int id) {
		super(id);
		this.temperature=temperature;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getStatus() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setTemperature() {
		this.temperature= temperature;
		
	}
	

}